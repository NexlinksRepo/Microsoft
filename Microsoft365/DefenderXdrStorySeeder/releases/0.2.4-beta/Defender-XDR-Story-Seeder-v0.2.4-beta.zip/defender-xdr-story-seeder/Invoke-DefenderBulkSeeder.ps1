#requires -Version 7.2

[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)]
    [ValidatePattern('^[^@\s]+@[^@\s]+\.[^@\s]+$')]
    [string]$GlobalAdminUpn,

    [ValidateRange(1, 50)]
    [int]$IncidentCount = 50,

    [switch]$CreateDemoAiAgents,

    [ValidateRange(0, 50)]
    [int]$DemoAgentCount = 10,

    [ValidateRange(0, 50)]
    [int]$AiIncidentCount = 0,

    [ValidateRange(1, 50)]
    [int]$StartAt = 1,

    [ValidateRange(500, 30000)]
    [int]$DelayMilliseconds = 1000,

    [int]$RandomSeed = 20261106,

    [string]$CatalogPath = (Join-Path $PSScriptRoot 'catalog\attack-catalog.json'),

    [string]$AiAgentCatalogPath = (Join-Path $PSScriptRoot 'catalog\ai-agent-catalog.json'),

    [string]$EndpointRosterPath = (Join-Path $PSScriptRoot 'catalog\endpoint-roster.json'),

    [string]$MailboxRosterPath = (Join-Path $PSScriptRoot 'catalog\mailbox-roster.json'),

    [switch]$Execute,

    [switch]$UseDeviceCode,

    [string]$ResumeManifestPath,

    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'artifacts')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProjectVersion = '0.2.4-beta'

. (Join-Path $PSScriptRoot 'DefenderXdrStorySeeder.Agent365.ps1')
. (Join-Path $PSScriptRoot 'DefenderXdrStorySeeder.Authentication.ps1')

function Connect-BulkSeederGraph {
    param([Parameter(Mandatory)][string]$LoginHint, [switch]$DeviceCode, [switch]$IncludeAgentScopes)

    $scopes = [System.Collections.Generic.List[string]]::new()
    @(
        'SecurityAlert.Create.All'
        'SecurityAlert.ReadWrite.All'
        'SecurityIncident.ReadWrite.All'
        'User.Read.All'
    ) | ForEach-Object { $scopes.Add($_) }
    if ($IncludeAgentScopes) {
        @(
            'AgentIdentityBlueprint.Create'
            'AgentIdentityBlueprintPrincipal.Create'
            'AgentIdentity.Create.All'
            'AgentRegistration.ReadWrite.All'
            'AgentIdentityBlueprint.Read.All'
            'AgentIdentityBlueprint.DeleteRestore.All'
            'AgentIdentity.DeleteRestore.All'
            'AgentIdentityBlueprintPrincipal.DeleteRestore.All'
        ) | ForEach-Object { $scopes.Add($_) }
    }
    return Connect-DefenderGraphSession -LoginHint $LoginHint -Scopes @($scopes) -UseDeviceCode:$DeviceCode
}

function Invoke-GraphRequestWithRetry {
    param(
        [Parameter(Mandatory)][ValidateSet('GET', 'PATCH')][string]$Method,
        [Parameter(Mandatory)][string]$Uri,
        [AllowNull()][System.Collections.IDictionary]$Body,
        [ValidateRange(1, 6)][int]$MaximumAttempts = 4
    )

    for ($attempt = 1; $attempt -le $MaximumAttempts; $attempt++) {
        try {
            $parameters = @{
                Method      = $Method
                Uri         = $Uri
                OutputType  = 'PSObject'
                ErrorAction = 'Stop'
            }
            if ($null -ne $Body) {
                $parameters.Body = ($Body | ConvertTo-Json -Depth 20 -Compress)
                $parameters.ContentType = 'application/json'
            }
            return Invoke-MgGraphRequest @parameters
        }
        catch {
            if ($attempt -eq $MaximumAttempts) {
                throw
            }
            $delaySeconds = [math]::Pow(2, $attempt - 1)
            Write-Warning "Graph request failed on attempt $attempt. Retrying in $delaySeconds second(s). $($_.Exception.Message)"
            Start-Sleep -Seconds $delaySeconds
        }
    }
}

function Get-GraphStatusCode {
    param([Parameter(Mandatory)]$ErrorRecord)

    try {
        if ($null -ne $ErrorRecord.Exception.Response.StatusCode) {
            return [int]$ErrorRecord.Exception.Response.StatusCode
        }
    }
    catch {
        return $null
    }
    return $null
}

function Find-ManualAlertByMarker {
    param(
        [Parameter(Mandatory)][string]$Marker,
        [AllowEmptyString()][string]$IncidentId,
        [Parameter(Mandatory)][DateTime]$NotBeforeUtc
    )

    $matches = [System.Collections.Generic.List[object]]::new()
    if (-not [string]::IsNullOrWhiteSpace($IncidentId)) {
        try {
            $escapedIncidentId = [uri]::EscapeDataString($IncidentId)
            $incident = Invoke-GraphRequestWithRetry `
                -Method GET `
                -Uri "https://graph.microsoft.com/v1.0/security/incidents/$escapedIncidentId`?`$expand=alerts" `
                -Body $null
            foreach ($alert in @($incident.alerts)) {
                $description = [string]$alert.description
                if (-not [string]::IsNullOrWhiteSpace($description) -and $description.IndexOf($Marker, [System.StringComparison]::Ordinal) -ge 0) {
                    $matches.Add($alert)
                }
            }
        }
        catch {
            Write-Verbose "Incident alert expansion was unavailable during POST reconciliation: $($_.Exception.Message)"
        }
    }

    if ($matches.Count -eq 0) {
        $notBefore = $NotBeforeUtc.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        $encodedFilter = [uri]::EscapeDataString("createdDateTime ge $notBefore")
        $uri = "https://graph.microsoft.com/v1.0/security/alerts_v2?`$filter=$encodedFilter&`$top=100"
        $pageCount = 0
        while (-not [string]::IsNullOrWhiteSpace($uri) -and $pageCount -lt 5) {
            $pageCount++
            $response = Invoke-GraphRequestWithRetry -Method GET -Uri $uri -Body $null
            foreach ($alert in @($response.value)) {
                $description = [string]$alert.description
                if ([string]::IsNullOrWhiteSpace($description) -or $description.IndexOf($Marker, [System.StringComparison]::Ordinal) -lt 0) {
                    continue
                }
                if (-not [string]::IsNullOrWhiteSpace($IncidentId) -and [string]$alert.incidentId -ne $IncidentId) {
                    continue
                }
                $matches.Add($alert)
            }
            $nextLinkProperty = $response.PSObject.Properties['@odata.nextLink']
            $uri = if ($null -eq $nextLinkProperty) { $null } else { [string]$nextLinkProperty.Value }
        }
    }

    if ($matches.Count -gt 1) {
        throw "More than one alert contains correlation marker '$Marker'. Stop and review the incident before continuing."
    }
    if ($matches.Count -eq 1) {
        return $matches[0]
    }
    return $null
}

function Wait-ManualAlertByMarker {
    param(
        [Parameter(Mandatory)][string]$Marker,
        [AllowEmptyString()][string]$IncidentId,
        [Parameter(Mandatory)][DateTime]$NotBeforeUtc,
        [ValidateRange(1, 12)][int]$MaximumAttempts = 6,
        [ValidateRange(0, 30)][int]$DelaySeconds = 5
    )

    for ($attempt = 1; $attempt -le $MaximumAttempts; $attempt++) {
        $alert = Find-ManualAlertByMarker -Marker $Marker -IncidentId $IncidentId -NotBeforeUtc $NotBeforeUtc
        if ($null -ne $alert) {
            return $alert
        }
        if ($attempt -lt $MaximumAttempts -and $DelaySeconds -gt 0) {
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    return $null
}

function Invoke-CreateManualAlertWithRecovery {
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Body,
        [Parameter(Mandatory)][string]$Marker,
        [AllowEmptyString()][string]$IncidentId,
        [Parameter(Mandatory)][DateTime]$AttemptedAtUtc,
        [switch]$ReconcileBeforePost
    )

    $reconciliationStart = $AttemptedAtUtc.ToUniversalTime().AddMinutes(-2)
    if ($ReconcileBeforePost) {
        $existingAlert = Wait-ManualAlertByMarker `
            -Marker $Marker `
            -IncidentId $IncidentId `
            -NotBeforeUtc $reconciliationStart `
            -MaximumAttempts 2 `
            -DelaySeconds 3
        if ($null -ne $existingAlert) {
            Write-Host "Recovered previously submitted alert '$($Body.title)' from Microsoft Graph." -ForegroundColor Cyan
            return $existingAlert
        }
    }

    for ($postAttempt = 1; $postAttempt -le 2; $postAttempt++) {
        try {
            return Invoke-MgGraphRequest `
                -Method POST `
                -Uri 'https://graph.microsoft.com/beta/security/alerts_v2' `
                -Body ($Body | ConvertTo-Json -Depth 20 -Compress) `
                -ContentType 'application/json' `
                -OutputType PSObject `
                -ErrorAction Stop
        }
        catch {
            $statusCode = Get-GraphStatusCode -ErrorRecord $_
            $ambiguousFailure = $null -eq $statusCode -or $statusCode -eq 408 -or $statusCode -eq 429 -or $statusCode -ge 500
            if (-not $ambiguousFailure) {
                throw
            }

            Write-Warning "Alert POST attempt $postAttempt returned an ambiguous HTTP $statusCode result. Checking Microsoft Graph for correlation marker $Marker before any retry."
            $recoveredAlert = Wait-ManualAlertByMarker `
                -Marker $Marker `
                -IncidentId $IncidentId `
                -NotBeforeUtc $reconciliationStart `
                -MaximumAttempts 12 `
                -DelaySeconds 5
            if ($null -ne $recoveredAlert) {
                Write-Host "Recovered alert '$($Body.title)' after the POST response was lost." -ForegroundColor Cyan
                return $recoveredAlert
            }
            if ($postAttempt -eq 1) {
                Write-Warning "No alert with marker $Marker appeared after reconciliation. Retrying this POST once."
                continue
            }
            throw
        }
    }
}

function Get-TenantIdentities {
    $identities = [System.Collections.Generic.List[object]]::new()
    $uri = 'https://graph.microsoft.com/v1.0/users?$select=id,displayName,userPrincipalName,mail,accountEnabled,userType&$top=999'

    while (-not [string]::IsNullOrWhiteSpace($uri)) {
        $response = Invoke-MgGraphRequest -Method GET -Uri $uri -OutputType PSObject -ErrorAction Stop
        foreach ($user in @($response.value)) {
            if ($user.accountEnabled -eq $true -and
                [string]$user.userType -eq 'Member' -and
                -not [string]::IsNullOrWhiteSpace([string]$user.userPrincipalName)) {
                $identities.Add([pscustomobject]@{
                    id                = [string]$user.id
                    displayName       = [string]$user.displayName
                    userPrincipalName = [string]$user.userPrincipalName
                    mail              = [string]$user.mail
                })
            }
        }

        if ($response -is [System.Collections.IDictionary] -and $response.Contains('@odata.nextLink')) {
            $uri = [string]$response['@odata.nextLink']
        }
        else {
            $nextLinkProperty = $response.PSObject.Properties['@odata.nextLink']
            $uri = if ($null -eq $nextLinkProperty) { $null } else { [string]$nextLinkProperty.Value }
        }
    }

    return @($identities)
}

function Get-ShuffledItems {
    param(
        [Parameter(Mandatory)][object[]]$Items,
        [Parameter(Mandatory)][System.Random]$Random
    )

    $shuffled = @($Items)
    for ($index = $shuffled.Count - 1; $index -gt 0; $index--) {
        $swapIndex = $Random.Next(0, $index + 1)
        $temporary = $shuffled[$index]
        $shuffled[$index] = $shuffled[$swapIndex]
        $shuffled[$swapIndex] = $temporary
    }
    return $shuffled
}

function Get-DeterministicSha256 {
    param([Parameter(Mandatory)][string]$Value)

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Value)
    $hashBytes = [System.Security.Cryptography.SHA256]::HashData($bytes)
    return [Convert]::ToHexString($hashBytes).ToLowerInvariant()
}

function Get-RelatedIpAddress {
    param([Parameter(Mandatory)][int]$Index)

    $prefixes = @('192.0.2', '198.51.100', '203.0.113')
    $prefix = $prefixes[($Index - 1) % $prefixes.Count]
    $lastOctet = 10 + (($Index * 7) % 220)
    return "$prefix.$lastOctet"
}

function Get-SafeSlug {
    param([Parameter(Mandatory)][string]$Value)

    $slug = $Value.ToLowerInvariant() -replace '[^a-z0-9]+', '-'
    return $slug.Trim('-')
}

function New-AlertEntities {
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Attack,
        [Parameter(Mandatory)][System.Collections.IDictionary]$Endpoint,
        [Parameter(Mandatory)][string]$UserPrincipalName,
        [AllowEmptyString()][string]$MailboxAddress,
        [AllowEmptyString()][string]$FictionalMailboxAddress,
        [Parameter(Mandatory)][int]$Index,
        [Parameter(Mandatory)][int]$StageNumber
    )

    $entities = [System.Collections.Generic.List[object]]::new()
    $entities.Add([ordered]@{
        entityType = 'device'; entityIdentifier = 'deviceName'; identifierValue = [string]$Endpoint.name; role = 'impacted'
    })
    $entities.Add([ordered]@{
        entityType = 'user'; entityIdentifier = 'userPrincipalName'; identifierValue = $UserPrincipalName; role = 'impacted'
    })

    if ([string]$Attack.workload -eq 'Email') {
        if (-not [string]::IsNullOrWhiteSpace($MailboxAddress)) {
            $entities.Add([ordered]@{
                entityType = 'mailbox'; entityIdentifier = 'mailboxPrimaryAddress'; identifierValue = $MailboxAddress; role = 'impacted'
            })
        }
        if (-not [string]::IsNullOrWhiteSpace($FictionalMailboxAddress) -and $FictionalMailboxAddress -ne $MailboxAddress) {
            $entities.Add([ordered]@{
                entityType = 'mailbox'; entityIdentifier = 'mailboxPrimaryAddress'; identifierValue = $FictionalMailboxAddress; role = 'impacted'
            })
        }
    }
    elseif ([string]$Attack.workload -eq 'CloudApp') {
        $entities.Add([ordered]@{
            entityType = 'cloudApplication'; entityIdentifier = 'name'; identifierValue = 'Microsoft 365'; role = 'impacted'
        })
        if (-not [string]::IsNullOrWhiteSpace($FictionalMailboxAddress)) {
            $entities.Add([ordered]@{
                entityType = 'mailbox'; entityIdentifier = 'mailboxPrimaryAddress'; identifierValue = $FictionalMailboxAddress; role = 'related'
            })
        }
    }
    elseif ([string]$Attack.workload -eq 'DefenderForCloud') {
        $resourceName = ([string]$Endpoint.name).ToLowerInvariant()
        $entities.Add([ordered]@{
            entityType = 'azureResource'
            entityIdentifier = 'resourceId'
            identifierValue = "/subscriptions/00000000-0000-0000-0000-000000000001/resourceGroups/rg-security-lab/providers/Microsoft.Compute/virtualMachines/$resourceName"
            role = 'impacted'
        })
    }

    $evidenceIndex = (($Index - 1) * 12) + $StageNumber
    $entities.Add([ordered]@{
        entityType = 'ip'; entityIdentifier = 'address'; identifierValue = Get-RelatedIpAddress -Index $evidenceIndex; role = 'related'
    })

    $slug = Get-SafeSlug -Value ([string]$Attack.title)
    $entities.Add([ordered]@{
        entityType = 'url'; entityIdentifier = 'url'; identifierValue = "https://$slug.security-lab.test/activity/$Index/$StageNumber"; role = 'related'
    })

    if (@('Endpoint', 'Hybrid', 'DefenderForCloud') -contains [string]$Attack.workload) {
        $entities.Add([ordered]@{
            entityType = 'file'; entityIdentifier = 'sha256'; identifierValue = Get-DeterministicSha256 -Value "$Index|$StageNumber|$($Attack.title)|$($Endpoint.name)"; role = 'related'
        })
    }

    return @($entities)
}

function Add-AiAgentEntities {
    param(
        [Parameter(Mandatory)][object[]]$Entities,
        [Parameter(Mandatory)][System.Collections.IDictionary]$AgentRecord
    )

    $result = [System.Collections.Generic.List[object]]::new()
    foreach ($entity in $Entities) {
        $result.Add($entity)
    }
    $result.Add([ordered]@{
        entityType = 'cloudApplication'
        entityIdentifier = 'name'
        identifierValue = [string]$AgentRecord.displayName
        role = 'impacted'
    })
    if (-not [string]::IsNullOrWhiteSpace([string]$AgentRecord.blueprintAppId)) {
        $result.Add([ordered]@{
            entityType = 'oAuthApplication'
            entityIdentifier = 'id'
            identifierValue = [string]$AgentRecord.blueprintAppId
            role = 'impacted'
        })
    }
    return @($result)
}

function Get-StageSeverity {
    param(
        [Parameter(Mandatory)][string]$IncidentSeverity,
        [Parameter(Mandatory)][int]$StageNumber
    )

    if ($StageNumber -eq 1) {
        return $IncidentSeverity.ToLowerInvariant()
    }

    $stageSeverities = @(
        'low', 'medium', 'medium', 'medium', 'high', 'low',
        'medium', 'medium', 'medium', 'high', 'high'
    )
    return $stageSeverities[$StageNumber - 2]
}

function Get-AttackStages {
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Attack,
        [Parameter(Mandatory)][int]$AlertCount
    )

    $stages = @(
        [ordered]@{
            title = [string]$Attack.title
            description = [string]$Attack.description
            category = [string]$Attack.category
            techniques = @($Attack.mitreTechniques)
            recommendedActions = [string]$Attack.recommendedActions
        },
        [ordered]@{
            title = 'Related authentication anomaly detected'
            description = 'An authentication anomaly involving {{UserPrincipalName}} preceded the primary activity associated with {{DeviceName}}.'
            category = 'InitialAccess'
            techniques = @('T1078')
            recommendedActions = 'Review the authentication source, session, and conditional-access result.'
        },
        [ordered]@{
            title = 'Suspicious command execution on endpoint'
            description = 'A command interpreter on {{DeviceName}} executed an unusual sequence under {{UserPrincipalName}}.'
            category = 'Execution'
            techniques = @('T1059.001')
            recommendedActions = 'Inspect command-line arguments, parent processes, and downloaded content.'
        },
        [ordered]@{
            title = 'Remote payload transfer observed'
            description = '{{DeviceName}} retrieved executable content from newly observed infrastructure during the active session.'
            category = 'CommandAndControl'
            techniques = @('T1105')
            recommendedActions = 'Block the source and analyze the transferred artifact.'
        },
        [ordered]@{
            title = 'Persistence mechanism established'
            description = 'A recurring execution mechanism was configured on {{DeviceName}} after the initial compromise.'
            category = 'Persistence'
            techniques = @('T1053.005')
            recommendedActions = 'Remove the persistence mechanism and review its creator and payload.'
        },
        [ordered]@{
            title = 'Credential access behavior detected'
            description = 'A process on {{DeviceName}} accessed credential-related material associated with {{UserPrincipalName}}.'
            category = 'CredentialAccess'
            techniques = @('T1003')
            recommendedActions = 'Isolate the endpoint and rotate potentially exposed credentials.'
        },
        [ordered]@{
            title = 'Internal discovery activity observed'
            description = '{{DeviceName}} enumerated accounts, groups, and reachable systems using {{UserPrincipalName}}.'
            category = 'Discovery'
            techniques = @('T1087.002', 'T1018')
            recommendedActions = 'Review enumeration commands and identify subsequent target systems.'
        },
        [ordered]@{
            title = 'Lateral movement attempt detected'
            description = 'Credentials associated with {{UserPrincipalName}} were used by {{DeviceName}} to access another system remotely.'
            category = 'LateralMovement'
            techniques = @('T1021.002')
            recommendedActions = 'Contain involved systems and review remote authentication and service activity.'
        },
        [ordered]@{
            title = 'Data collection and staging observed'
            description = 'Files accessible from {{DeviceName}} were collected and staged before outbound transfer.'
            category = 'Collection'
            techniques = @('T1074.001', 'T1560.001')
            recommendedActions = 'Preserve the staged content and identify its source and sensitivity.'
        },
        [ordered]@{
            title = 'Periodic outbound beaconing detected'
            description = '{{DeviceName}} contacted external infrastructure at regular intervals during the incident.'
            category = 'CommandAndControl'
            techniques = @('T1071.001')
            recommendedActions = 'Block the destination and identify the process responsible for the traffic.'
        },
        [ordered]@{
            title = 'Data transfer to external host'
            description = '{{DeviceName}} transferred staged data to an external destination after collection activity.'
            category = 'Exfiltration'
            techniques = @('T1041')
            recommendedActions = 'Block the destination and determine the scope of transferred data.'
        },
        [ordered]@{
            title = 'Destructive follow-on activity detected'
            description = '{{DeviceName}} displayed recovery-inhibition or file-impact behavior after data transfer.'
            category = 'Impact'
            techniques = @('T1490', 'T1486')
            recommendedActions = 'Isolate the device, protect backups, and begin recovery procedures.'
        }
    )

    return @($stages | Select-Object -First $AlertCount)
}

function Get-AiAttackStages {
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Attack,
        [Parameter(Mandatory)][int]$AlertCount
    )

    $stages = @(
        [ordered]@{ title = [string]$Attack.title; description = [string]$Attack.description; category = [string]$Attack.category; techniques = @($Attack.mitreTechniques); recommendedActions = [string]$Attack.recommendedActions },
        [ordered]@{ title = 'AI agent identity observed in unexpected context'; description = '{{AgentName}} was represented outside its expected dormant demo context. Blueprint {{BlueprintId}}; agent identity {{AgentIdentityId}}.'; category = 'InitialAccess'; techniques = @('T1078'); recommendedActions = 'Review the agent identity, sponsor, owner, and registry record.' },
        [ordered]@{ title = 'AI agent delegated access boundary exceeded'; description = '{{AgentName}} was associated with access beyond the {{AuthorityProfile}} authority profile.'; category = 'PrivilegeEscalation'; techniques = @('T1068'); recommendedActions = 'Review declared permissions and remove unnecessary consent.' },
        [ordered]@{ title = 'AI agent queried sensitive data source'; description = '{{AgentName}} was associated with a sensitive data query involving {{UserPrincipalName}}.'; category = 'Collection'; techniques = @('T1213'); recommendedActions = 'Validate the data source and least-privilege boundary.' },
        [ordered]@{ title = 'AI agent accessed untrusted external content'; description = '{{AgentName}} was associated with an untrusted external URL from {{DeviceName}}.'; category = 'CommandAndControl'; techniques = @('T1105'); recommendedActions = 'Review outbound destinations and content controls.' },
        [ordered]@{ title = 'AI agent permission use anomaly detected'; description = '{{AgentName}} was associated with unusual use of its declared {{ExecutionMode}} permissions.'; category = 'CredentialAccess'; techniques = @('T1550'); recommendedActions = 'Review permission use and sign-in evidence for the agent identity.' },
        [ordered]@{ title = 'AI agent enumerated tenant resources'; description = '{{AgentName}} was associated with resource discovery beyond its expected task.'; category = 'Discovery'; techniques = @('T1087.004'); recommendedActions = 'Constrain discovery permissions and inspect queried resources.' },
        [ordered]@{ title = 'AI agent collected cross-context information'; description = '{{AgentName}} was associated with data collection across unrelated contexts.'; category = 'Collection'; techniques = @('T1114', 'T1213'); recommendedActions = 'Review data boundaries and sponsor-approved use cases.' },
        [ordered]@{ title = 'AI agent staged generated output'; description = '{{AgentName}} was associated with staging output before transfer.'; category = 'Collection'; techniques = @('T1074'); recommendedActions = 'Inspect staged content and retention controls.' },
        [ordered]@{ title = 'AI agent contacted external service'; description = '{{AgentName}} was associated with a repeated external service connection.'; category = 'CommandAndControl'; techniques = @('T1071.001'); recommendedActions = 'Validate the destination and block unapproved connectors.' },
        [ordered]@{ title = 'AI agent transferred collected content'; description = '{{AgentName}} was associated with transferring staged content to an external destination.'; category = 'Exfiltration'; techniques = @('T1041'); recommendedActions = 'Determine the content scope and revoke unauthorized access.' },
        [ordered]@{ title = 'AI agent governance response recommended'; description = 'Review {{AgentName}}, blueprint {{BlueprintId}}, identity {{AgentIdentityId}}, and registry record {{RegistrationId}} as one governed object set.'; category = 'Impact'; techniques = @('T1531'); recommendedActions = 'Disable or remove the demo identity set if it is no longer required.' }
    )
    return @($stages | Select-Object -First $AlertCount)
}

function Expand-StoryText {
    param(
        [AllowEmptyString()][string]$Text,
        [Parameter(Mandatory)][string]$DeviceName,
        [Parameter(Mandatory)][string]$UserPrincipalName,
        [AllowNull()][System.Collections.IDictionary]$AgentRecord
    )

    $expanded = $Text.Replace('{{DeviceName}}', $DeviceName).Replace('{{UserPrincipalName}}', $UserPrincipalName)
    if ($null -ne $AgentRecord) {
        $values = [ordered]@{
            '{{AgentName}}' = [string]$AgentRecord.displayName
            '{{AuthorityProfile}}' = [string]$AgentRecord.authorityProfile
            '{{ExecutionMode}}' = [string]$AgentRecord.executionMode
            '{{BlueprintId}}' = if ([string]::IsNullOrWhiteSpace([string]$AgentRecord.blueprintId)) { 'unavailable' } else { [string]$AgentRecord.blueprintId }
            '{{AgentIdentityId}}' = if ([string]::IsNullOrWhiteSpace([string]$AgentRecord.agentIdentityId)) { 'unavailable' } else { [string]$AgentRecord.agentIdentityId }
            '{{RegistrationId}}' = if ([string]::IsNullOrWhiteSpace([string]$AgentRecord.agentRegistrationId)) { 'unavailable' } else { [string]$AgentRecord.agentRegistrationId }
        }
        foreach ($placeholder in $values.Keys) {
            $expanded = $expanded.Replace($placeholder, [string]$values[$placeholder])
        }
    }
    return $expanded
}

function Save-RunManifest {
    param([Parameter(Mandatory)][System.Collections.IDictionary]$Manifest, [Parameter(Mandatory)][string]$Path)
    $Manifest | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $Path -Encoding utf8
}

$resolvedCatalogPath = (Resolve-Path -LiteralPath $CatalogPath).Path
$resolvedAiAgentCatalogPath = (Resolve-Path -LiteralPath $AiAgentCatalogPath).Path
$resolvedEndpointRosterPath = (Resolve-Path -LiteralPath $EndpointRosterPath).Path
$resolvedMailboxRosterPath = (Resolve-Path -LiteralPath $MailboxRosterPath).Path
$catalog = Get-Content -LiteralPath $resolvedCatalogPath -Raw | ConvertFrom-Json -AsHashtable
$aiAgentCatalog = Get-Content -LiteralPath $resolvedAiAgentCatalogPath -Raw | ConvertFrom-Json -AsHashtable
$endpointRoster = Get-Content -LiteralPath $resolvedEndpointRosterPath -Raw | ConvertFrom-Json -AsHashtable
$mailboxRoster = Get-Content -LiteralPath $resolvedMailboxRosterPath -Raw | ConvertFrom-Json -AsHashtable
$allAttacks = @($catalog.attacks)
$allAgentDefinitions = @($aiAgentCatalog.agents)
$random = [System.Random]::new($RandomSeed)
$allEndpoints = @(Get-ShuffledItems -Items @($endpointRoster.endpoints) -Random $random)
$allMailboxAliases = @($mailboxRoster.mailboxes)

if ($allAttacks.Count -lt 50) {
    throw "The attack catalog contains only $($allAttacks.Count) entries; 50 are required."
}
if ($allEndpoints.Count -lt 1) {
    throw 'The endpoint roster is empty.'
}
if ($allMailboxAliases.Count -lt 1) {
    throw 'The mailbox roster is empty.'
}
if ($AiIncidentCount -gt $IncidentCount) {
    throw 'AiIncidentCount cannot exceed IncidentCount.'
}
if ($CreateDemoAiAgents -and $DemoAgentCount -lt 1) {
    throw 'DemoAgentCount must be at least 1 when CreateDemoAiAgents is enabled.'
}
if ($AiIncidentCount -gt 0 -and $allAgentDefinitions.Count -lt 1) {
    throw 'The AI-agent catalog is empty.'
}

$traditionalIncidentCount = $IncidentCount - $AiIncidentCount
if (($StartAt - 1 + $traditionalIncidentCount) -gt $allAttacks.Count) {
    throw "StartAt $StartAt with $traditionalIncidentCount traditional incident(s) exceeds the $($allAttacks.Count)-entry catalog."
}

$selectedAttacks = [System.Collections.Generic.List[object]]::new()
foreach ($attack in @($allAttacks | Select-Object -Skip ($StartAt - 1) -First $traditionalIncidentCount)) {
    $attack['isAiScenario'] = $false
    $attack['aiDefinitionIndex'] = $null
    $selectedAttacks.Add($attack)
}
$plannedAgentPoolCount = if ($CreateDemoAiAgents) {
    $DemoAgentCount
}
else {
    [math]::Max(1, [math]::Min($AiIncidentCount, $allAgentDefinitions.Count))
}
for ($aiOffset = 0; $aiOffset -lt $AiIncidentCount; $aiOffset++) {
    # Cycle incidents through the selected agent pool first, then map each pool
    # position to its catalog definition. This keeps the story and associated
    # agent aligned when fewer agents than AI incidents are requested.
    $agentPoolIndex = $aiOffset % $plannedAgentPoolCount
    $definitionIndex = $agentPoolIndex % $allAgentDefinitions.Count
    $definition = $allAgentDefinitions[$definitionIndex]
    $selectedAttacks.Add([ordered]@{
        id = 1000 + $aiOffset + 1
        title = [string]$definition.title
        workload = 'SecurityForAI'
        category = [string]$definition.category
        severity = [string]$definition.severity
        mitreTechniques = @($definition.mitreTechniques)
        description = "Manual Defender XDR proxy story for {{AgentName}}. $([string]$definition.summary) Blueprint={{BlueprintId}}; AgentIdentity={{AgentIdentityId}}; Registry={{RegistrationId}}."
        summary = [string]$definition.summary
        recommendedActions = [string]$definition.recommendedActions
        isAiScenario = $true
        aiDefinitionIndex = $definitionIndex
    })
}

$plan = for ($offset = 0; $offset -lt $selectedAttacks.Count; $offset++) {
    $catalogIndex = $StartAt + $offset
    $attack = $selectedAttacks[$offset]
    $endpoint = $allEndpoints[($catalogIndex - 1) % $allEndpoints.Count]
    [pscustomobject]@{
        Number   = $catalogIndex
        Title    = [string]$attack.title
        Severity = [string]$attack.severity
        Category = [string]$attack.category
        Workload = [string]$attack.workload
        Endpoint = [string]$endpoint.name
        Identity = if ([bool]$attack.isAiScenario) { 'Tenant identity plus demo AI agent' } else { 'Selected from tenant at run time' }
        AssociationMode = if ([bool]$attack.isAiScenario) { 'manualProxy' } else { 'manualStory' }
        AgentPoolPosition = if ([bool]$attack.isAiScenario) { 1 + ($offset - $traditionalIncidentCount) % $plannedAgentPoolCount } else { $null }
        AgentCatalogId = if ([bool]$attack.isAiScenario) { 1 + [int]$attack.aiDefinitionIndex } else { $null }
        Alerts   = 10 + (($catalogIndex - 1) % 3)
    }
}

if (-not $Execute) {
    Write-Host 'DRY RUN — no Microsoft 365 data was changed.' -ForegroundColor Cyan
    $plan | Format-Table -AutoSize | Out-Host
    return [pscustomobject]@{
        Mode          = 'DryRun'
        Version       = $ProjectVersion
        IncidentCount = $selectedAttacks.Count
        DemoAgentCount = if ($CreateDemoAiAgents) { $DemoAgentCount } else { 0 }
        AiIncidentCount = $AiIncidentCount
        StartAt       = $StartAt
        Plan          = $plan
    }
}

$totalAlertCount = ($plan | Measure-Object -Property Alerts -Sum).Sum
$target = "Microsoft Defender tenant selected by $GlobalAdminUpn"
$confirmationAction = "Create $($selectedAttacks.Count) incidents containing exactly $totalAlertCount alerts"
if ($CreateDemoAiAgents) {
    $confirmationAction += ", plus $DemoAgentCount dormant demo AI agents; $AiIncidentCount incident(s) will use manual AI proxy stories"
}
if (-not $PSCmdlet.ShouldProcess($target, $confirmationAction)) {
    return
}

if (-not (Test-Path -LiteralPath $OutputDirectory)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}
$runId = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
$manifestPath = Join-Path $OutputDirectory "bulk-seed-run-$runId.json"
if (-not [string]::IsNullOrWhiteSpace($ResumeManifestPath)) {
    $manifestPath = (Resolve-Path -LiteralPath $ResumeManifestPath).Path
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json -AsHashtable
    if ([string]$manifest.projectVersion -ne $ProjectVersion) {
        throw "Resume manifest version '$($manifest.projectVersion)' does not match $ProjectVersion."
    }
    if ([int]$manifest.requestedCount -ne $IncidentCount) {
        throw "Resume manifest requested $($manifest.requestedCount) incidents. Re-run with -IncidentCount $($manifest.requestedCount)."
    }
    $hasPartialIncident = @($manifest.incidents).Count -gt [int]$manifest.completedCount
    if ($hasPartialIncident -and [int]$manifest.schemaVersion -lt 3) {
        throw 'This partial manifest predates safe POST-timeout recovery and has no correlation marker for its uncertain alert. Clean up that run or start a fresh run; do not resume it.'
    }
    $runId = [string]$manifest.runId
    $manifest.succeeded = $false
    $manifest.error = $null
    $manifest.completedAtUtc = $null
    $manifest.resumptionCount = 1 + [int]$manifest.resumptionCount
    $manifest.resumedAtUtc = [DateTime]::UtcNow.ToString('o')
}
else {
    $manifest = [ordered]@{
        schemaVersion     = 3
        projectVersion    = $ProjectVersion
        runId             = $runId
        startedAtUtc      = [DateTime]::UtcNow.ToString('o')
        resumedAtUtc      = $null
        resumptionCount   = 0
        completedAtUtc    = $null
        succeeded         = $false
        tenantId          = $null
        signedInAccount   = $null
        globalAdminUpn    = $GlobalAdminUpn
        randomSeed        = $RandomSeed
        requestedCount    = $IncidentCount
        requestedAlertCount = $totalAlertCount
        requestedDemoAgentCount = if ($CreateDemoAiAgents) { $DemoAgentCount } else { 0 }
        requestedAiIncidentCount = $AiIncidentCount
        startAt           = $StartAt
        completedCount    = 0
        completedAlertCount = 0
        discoveredIdentityCount = 0
        discoveredMailboxCount = 0
        capabilities      = [ordered]@{
            agent365License = 'notDirectlyVerified'
            entraAgentId = if ($CreateDemoAiAgents) { 'pending' } else { 'notRequested' }
            agentRegistry = if ($CreateDemoAiAgents) { 'pending' } else { 'notRequested' }
            defenderSecurityForAi = if ($AiIncidentCount -gt 0) { 'manualProxyOnly' } else { 'notRequested' }
        }
        agents            = @()
        incidents         = @()
        resume            = [ordered]@{ nextPlanOffset = 0; remainingIncidentCount = $IncidentCount }
        error             = $null
    }
}
Save-RunManifest -Manifest $manifest -Path $manifestPath

$context = $null
$executionError = $null
try {
    $context = Connect-BulkSeederGraph -LoginHint $GlobalAdminUpn -DeviceCode:$UseDeviceCode -IncludeAgentScopes:$CreateDemoAiAgents
    $manifest.tenantId = [string]$context.TenantId
    $manifest.signedInAccount = [string]$context.Account

    $tenantIdentities = @(Get-TenantIdentities)
    if ($tenantIdentities.Count -eq 0) {
        $tenantIdentities = @([pscustomobject]@{
            id = $null
            displayName = $GlobalAdminUpn
            userPrincipalName = $GlobalAdminUpn
            mail = $GlobalAdminUpn
        })
    }

    $ownerIdentity = @($tenantIdentities | Where-Object { [string]$_.userPrincipalName -ieq $GlobalAdminUpn } | Select-Object -First 1)
    if ($CreateDemoAiAgents -and ($ownerIdentity.Count -eq 0 -or [string]::IsNullOrWhiteSpace([string]$ownerIdentity[0].id))) {
        throw "The signed-in owner '$GlobalAdminUpn' could not be resolved to a tenant user object."
    }

    if ($CreateDemoAiAgents -and @($manifest.agents).Count -eq 0) {
        Write-Host "Creating up to $DemoAgentCount dormant demo AI agent identity set(s)..." -ForegroundColor Cyan
        $skipAgentRegistration = $false
        $registryDenialWasReported = $false
        for ($agentOffset = 0; $agentOffset -lt $DemoAgentCount; $agentOffset++) {
            $definition = $allAgentDefinitions[$agentOffset % $allAgentDefinitions.Count]
            $agentRecord = New-DemoAiAgent `
                -Definition $definition `
                -OwnerId ([string]$ownerIdentity[0].id) `
                -RunId $runId `
                -Sequence ($agentOffset + 1) `
                -SkipAgentRegistration:$skipAgentRegistration
            $manifest.agents = @($manifest.agents) + $agentRecord
            Save-RunManifest -Manifest $manifest -Path $manifestPath
            if ($null -ne $agentRecord.registrationError -and @('401', '403') -contains [string]$agentRecord.registrationError.statusCode) {
                $skipAgentRegistration = $true
                if (-not $registryDenialWasReported) {
                    Write-Warning "Agent Registry rejected the first registration with HTTP $($agentRecord.registrationError.statusCode). Remaining registry calls will be skipped, while Entra agent identities continue. Response: $($agentRecord.registrationError.responseBody)"
                    $registryDenialWasReported = $true
                }
            }
            elseif ([string]$agentRecord.creationStatus -ne 'created' -and -not $skipAgentRegistration) {
                Write-Warning "Agent '$($agentRecord.displayName)' was created only partially. AI incidents will still use a truthful manual proxy association."
            }
        }
        $manifest.capabilities.entraAgentId = if (@($manifest.agents | Where-Object { $_.componentStatus.blueprint -eq 'created' }).Count -gt 0) { 'available' } else { 'unavailable' }
        $manifest.capabilities.agentRegistry = if (@($manifest.agents | Where-Object { $_.componentStatus.agentRegistration -eq 'created' }).Count -gt 0) {
            'available'
        }
        elseif (@($manifest.agents | Where-Object { $null -ne $_.registrationError -and @('401', '403') -contains [string]$_.registrationError.statusCode }).Count -gt 0) {
            'denied'
        }
        else {
            'unavailable'
        }
        Save-RunManifest -Manifest $manifest -Path $manifestPath
    }

    $nonAdminIdentities = @($tenantIdentities | Where-Object { $_.userPrincipalName -ne $GlobalAdminUpn })
    if ($nonAdminIdentities.Count -eq 0) {
        $nonAdminIdentities = $tenantIdentities
    }
    $identityPool = @(Get-ShuffledItems -Items $nonAdminIdentities -Random $random)
    $mailIdentityPool = @($identityPool | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.mail) })
    if ($mailIdentityPool.Count -eq 0) {
        $mailIdentityPool = $identityPool
    }

    $tenantDomain = ($GlobalAdminUpn -split '@', 2)[1]
    $fictionalMailboxes = @(
        foreach ($mailbox in $allMailboxAliases) {
            [pscustomobject]@{
                displayName = [string]$mailbox.displayName
                address = "$([string]$mailbox.alias)@$tenantDomain"
            }
        }
    )
    $fictionalMailboxes = @(Get-ShuffledItems -Items $fictionalMailboxes -Random $random)

    $agentPool = @($manifest.agents)
    if ($agentPool.Count -eq 0 -and $AiIncidentCount -gt 0) {
        $agentPool = @(
            for ($agentIndex = 0; $agentIndex -lt [math]::Max(1, [math]::Min($AiIncidentCount, $allAgentDefinitions.Count)); $agentIndex++) {
                $definition = $allAgentDefinitions[$agentIndex % $allAgentDefinitions.Count]
                [ordered]@{
                    sequence = $agentIndex + 1
                    catalogId = [int]$definition.id
                    displayName = [string]$definition.name
                    description = [string]$definition.description
                    authorityProfile = [string]$definition.authorityProfile
                    executionMode = [string]$definition.executionMode
                    declaredPermissions = @($definition.permissions)
                    credentialsCreated = $false
                    permissionGrantsCreated = @()
                    blueprintId = $null
                    blueprintAppId = $null
                    blueprintPrincipalId = $null
                    agentIdentityId = $null
                    agentIdentityAppId = $null
                    agentRegistrationId = $null
                    creationStatus = 'proxyOnly'
                    componentStatus = [ordered]@{ blueprint = 'notRequested'; blueprintPrincipal = 'notRequested'; agentIdentity = 'notRequested'; agentRegistration = 'notRequested' }
                    errors = @()
                }
            }
        )
    }

    $manifest.discoveredIdentityCount = $identityPool.Count
    $manifest.discoveredMailboxCount = $mailIdentityPool.Count
    Save-RunManifest -Manifest $manifest -Path $manifestPath

    $resumeOffset = [int]$manifest.completedCount
    for ($offset = $resumeOffset; $offset -lt $selectedAttacks.Count; $offset++) {
        $catalogIndex = $StartAt + $offset
        $attack = $selectedAttacks[$offset]
        $isAiScenario = [bool]$attack.isAiScenario
        $agentRecord = if ($isAiScenario) { $agentPool[($offset - $traditionalIncidentCount) % $agentPool.Count] } else { $null }
        $endpoint = $allEndpoints[($catalogIndex - 1) % $allEndpoints.Count]
        if ([string]$attack.workload -eq 'Email') {
            $identity = $mailIdentityPool[($catalogIndex - 1) % $mailIdentityPool.Count]
        }
        else {
            $identity = $identityPool[($catalogIndex - 1) % $identityPool.Count]
        }
        $impactedUserPrincipalName = [string]$identity.userPrincipalName
        $impactedMailboxAddress = [string]$identity.mail
        if ([string]::IsNullOrWhiteSpace($impactedMailboxAddress) -and [string]$attack.workload -eq 'Email') {
            $impactedMailboxAddress = $impactedUserPrincipalName
        }
        $fictionalMailbox = $fictionalMailboxes[($catalogIndex - 1) % $fictionalMailboxes.Count]
        $fictionalMailboxAddress = [string]$fictionalMailbox.address
        $alertCount = 10 + (($catalogIndex - 1) % 3)
        $stages = if ($isAiScenario) {
            Get-AiAttackStages -Attack $attack -AlertCount $alertCount
        }
        else {
            Get-AttackStages -Attack $attack -AlertCount $alertCount
        }
        $incidentId = $null
        $incidentRecord = $null
        $existingIncidentRecords = @($manifest.incidents)
        if ($offset -eq $resumeOffset -and $existingIncidentRecords.Count -gt $resumeOffset) {
            $candidate = $existingIncidentRecords[$resumeOffset]
            if ([int]$candidate.catalogNumber -ne $catalogIndex -or [string]$candidate.title -ne [string]$attack.title) {
                throw "The partial manifest incident does not match plan item $catalogIndex ('$([string]$attack.title)')."
            }
            $incidentRecord = $candidate
            $incidentId = [string]$incidentRecord.incidentId
            if (-not $incidentRecord.ContainsKey('pendingAlert')) {
                $incidentRecord['pendingAlert'] = $null
            }
            $recordedStages = @($incidentRecord.alerts | ForEach-Object { [int]$_.stage })
            $expectedRecordedStages = if ($recordedStages.Count -eq 0) { @() } else { @(1..$recordedStages.Count) }
            if ($recordedStages.Count -gt $stages.Count -or ($recordedStages -join ',') -ne ($expectedRecordedStages -join ',')) {
                throw "The partial incident $($incidentRecord.incidentId) has a non-sequential alert manifest and cannot be resumed automatically."
            }
            if ($null -ne $incidentRecord.pendingAlert -and [int]$incidentRecord.pendingAlert.stage -ne ($recordedStages.Count + 1)) {
                throw "The partial incident $($incidentRecord.incidentId) has an unexpected pending alert stage and cannot be resumed automatically."
            }
            Write-Host "Resuming partial incident $($incidentRecord.incidentId) at alert $($recordedStages.Count + 1) of $($stages.Count)." -ForegroundColor Cyan
        }
        else {
            $incidentRecord = [ordered]@{
                catalogNumber  = $catalogIndex
                incidentId     = $null
                incidentWebUrl = $null
                title          = [string]$attack.title
                severity       = [string]$attack.severity
                category       = [string]$attack.category
                endpoint       = [string]$endpoint.name
                impactedIdentity = $impactedUserPrincipalName
                impactedMailbox = $impactedMailboxAddress
                fictionalMailbox = $fictionalMailboxAddress
                scenarioContext = switch ([string]$attack.workload) {
                    'SecurityForAI' { 'Security for AI manual proxy' }
                    'Email' { 'Defender for Office 365' }
                    'Identity' { 'Defender for Identity' }
                    'CloudApp' { 'Defender for Cloud Apps' }
                    'DefenderForCloud' { 'Defender for Cloud' }
                    'Endpoint' { 'Defender for Endpoint' }
                    default { 'Microsoft Defender XDR' }
                }
                associationMode = if ($isAiScenario) { 'manualProxy' } else { 'manualStory' }
                agentAssetLinked = $false
                agent = if ($isAiScenario) {
                    [ordered]@{
                        displayName = [string]$agentRecord.displayName
                        authorityProfile = [string]$agentRecord.authorityProfile
                        executionMode = [string]$agentRecord.executionMode
                        blueprintId = [string]$agentRecord.blueprintId
                        blueprintAppId = [string]$agentRecord.blueprintAppId
                        blueprintPrincipalId = [string]$agentRecord.blueprintPrincipalId
                        agentIdentityId = [string]$agentRecord.agentIdentityId
                        agentRegistrationId = [string]$agentRecord.agentRegistrationId
                        creationStatus = [string]$agentRecord.creationStatus
                    }
                } else { $null }
                status         = 'creating'
                alerts         = @()
                pendingAlert   = $null
            }
            $manifest.incidents = @($manifest.incidents) + $incidentRecord
            Save-RunManifest -Manifest $manifest -Path $manifestPath
        }

        $firstPendingStageOffset = @($incidentRecord.alerts).Count
        for ($stageOffset = $firstPendingStageOffset; $stageOffset -lt $stages.Count; $stageOffset++) {
            $stageNumber = $stageOffset + 1
            $stage = $stages[$stageOffset]
            $entities = New-AlertEntities `
                -Attack $attack `
                -Endpoint $endpoint `
                -UserPrincipalName $impactedUserPrincipalName `
                -MailboxAddress $impactedMailboxAddress `
                -FictionalMailboxAddress $fictionalMailboxAddress `
                -Index $catalogIndex `
                -StageNumber $stageNumber
            if ($isAiScenario) {
                $entities = Add-AiAgentEntities -Entities $entities -AgentRecord $agentRecord
            }
            $correlationMarker = "[MXDR-SEED:$runId`:$catalogIndex`:$stageNumber]"
            $alertDescription = Expand-StoryText `
                -Text ([string]$stage.description) `
                -DeviceName ([string]$endpoint.name) `
                -UserPrincipalName $impactedUserPrincipalName `
                -AgentRecord $agentRecord
            $alertDescription = "$alertDescription`n`nSeeder correlation marker: $correlationMarker"
            $alertBody = [ordered]@{
                '@odata.type'             = '#microsoft.graph.security.manualAlert'
                title                     = [string]$stage.title
                description               = $alertDescription
                category                  = [string]$stage.category
                severity                  = Get-StageSeverity -IncidentSeverity ([string]$attack.severity) -StageNumber $stageNumber
                recommendedActions        = [string]$stage.recommendedActions
                mitreTechniques           = @($stage.techniques)
                isExcludedFromCorrelation = $true
                entityDefinitions         = $entities
            }
            if ($stageNumber -gt 1) {
                $alertBody.linkToIncident = [long]$incidentId
            }

            $globalAlertNumber = $manifest.completedAlertCount + 1
            Write-Progress -Activity 'Creating Defender XDR incidents' -Status "Incident $catalogIndex, alert $stageNumber of ${alertCount}: $($stage.title)" -PercentComplete (($globalAlertNumber / $totalAlertCount) * 100)
            $existingPendingAlert = $incidentRecord.pendingAlert
            $reconcileBeforePost = $null -ne $existingPendingAlert -and [string]$existingPendingAlert.marker -eq $correlationMarker
            $attemptedAtUtc = if ($reconcileBeforePost) {
                [DateTime]::Parse([string]$existingPendingAlert.attemptedAtUtc).ToUniversalTime()
            }
            else {
                [DateTime]::UtcNow
            }
            $incidentRecord.pendingAlert = [ordered]@{
                stage = $stageNumber
                marker = $correlationMarker
                attemptedAtUtc = $attemptedAtUtc.ToString('o')
                title = [string]$stage.title
            }
            Save-RunManifest -Manifest $manifest -Path $manifestPath
            $alertResponse = Invoke-CreateManualAlertWithRecovery `
                -Body $alertBody `
                -Marker $correlationMarker `
                -IncidentId $incidentId `
                -AttemptedAtUtc $attemptedAtUtc `
                -ReconcileBeforePost:$reconcileBeforePost
            if ($stageNumber -eq 1) {
                $incidentId = [string]$alertResponse.incidentId
                if ([string]::IsNullOrWhiteSpace($incidentId)) {
                    throw "Alert '$($attack.title)' was created, but Microsoft Graph did not return an incident ID."
                }
                $incidentRecord.incidentId = $incidentId
                $incidentRecord.incidentWebUrl = [string]$alertResponse.incidentWebUrl

                # A newly created incident can take a few seconds to become
                # addressable by ID. Wait before linking the remaining alerts.
                Invoke-GraphRequestWithRetry `
                    -Method GET `
                    -Uri "https://graph.microsoft.com/beta/security/incidents/$incidentId" `
                    -Body $null `
                    -MaximumAttempts 6 | Out-Null
            }

            $incidentRecord.alerts = @($incidentRecord.alerts) + [ordered]@{
                stage       = $stageNumber
                alertId     = [string]$alertResponse.id
                alertWebUrl = [string]$alertResponse.alertWebUrl
                title       = [string]$stage.title
                severity    = [string]$alertBody.severity
                category    = [string]$stage.category
                correlationMarker = $correlationMarker
            }
            $incidentRecord.pendingAlert = $null
            $manifest.completedAlertCount++
            Save-RunManifest -Manifest $manifest -Path $manifestPath

            if ($stageNumber -lt $alertCount) {
                Start-Sleep -Milliseconds $DelayMilliseconds
            }
        }

        $resolved = (($catalogIndex % 5) -eq 0)
        $incidentBody = [ordered]@{
            displayName    = [string]$attack.title
            description    = Expand-StoryText -Text ([string]$attack.description) -DeviceName ([string]$endpoint.name) -UserPrincipalName $impactedUserPrincipalName -AgentRecord $agentRecord
            summary        = if ($isAiScenario) { "Manual proxy only; no native AI detection or agent-asset linkage is claimed. $([string]$attack.summary)" } else { [string]$attack.summary }
            severity       = ([string]$attack.severity).ToLowerInvariant()
            classification = 'informationalExpectedActivity'
            determination  = 'securityTesting'
            status         = if ($resolved) { 'resolved' } else { 'active' }
        }
        if ($resolved) {
            $incidentBody.resolvingComment = 'Validated during an authorized security-testing exercise.'
        }

        $updatedIncident = Invoke-GraphRequestWithRetry -Method PATCH -Uri "https://graph.microsoft.com/beta/security/incidents/$incidentId" -Body $incidentBody
        $incidentRecord.incidentWebUrl = [string]$updatedIncident.incidentWebUrl
        $incidentRecord.status = if ($resolved) { 'resolved' } else { 'active' }
        $manifest.completedCount++
        $manifest.resume.nextPlanOffset = $manifest.completedCount
        $manifest.resume.remainingIncidentCount = $IncidentCount - $manifest.completedCount
        Save-RunManifest -Manifest $manifest -Path $manifestPath

        if ($offset -lt ($selectedAttacks.Count - 1)) {
            Start-Sleep -Milliseconds $DelayMilliseconds
        }
    }

    $manifest.succeeded = $true
    $manifest.completedAtUtc = [DateTime]::UtcNow.ToString('o')
}
catch {
    $executionError = $_
    $manifest.error = $_.Exception.Message
    $manifest.completedAtUtc = [DateTime]::UtcNow.ToString('o')
}
finally {
    Write-Progress -Activity 'Creating Defender XDR incidents' -Completed
    Save-RunManifest -Manifest $manifest -Path $manifestPath
}

if ($null -ne $executionError) {
    $remainingCount = $IncidentCount - $manifest.completedCount
    Write-Warning "Bulk seeding stopped after $($manifest.completedCount) complete incident(s) and $($manifest.completedAlertCount) alert(s). Resume with the same inputs plus -ResumeManifestPath '$manifestPath'; schema-3 manifests reconcile any pending alert and continue the same partial incident. Remaining incidents: $remainingCount."
    throw $executionError
}

Write-Host "Created $($manifest.completedCount) Defender XDR incidents containing $($manifest.completedAlertCount) alerts." -ForegroundColor Green
Write-Host "Run manifest: $manifestPath"

[pscustomobject]@{
    Mode           = 'Executed'
    Version        = $ProjectVersion
    IncidentCount  = $manifest.completedCount
    AlertCount     = $manifest.completedAlertCount
    AgentCount     = @($manifest.agents).Count
    AiIncidentCount = $AiIncidentCount
    FirstIncident  = if ($manifest.completedCount) { $manifest.incidents[0].incidentWebUrl } else { $null }
    ManifestPath   = $manifestPath
}


